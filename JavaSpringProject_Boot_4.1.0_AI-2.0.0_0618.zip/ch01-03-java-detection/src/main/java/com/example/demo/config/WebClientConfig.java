package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    ExchangeStrategies exchangeStrategies() {
        return ExchangeStrategies.builder()
                .codecs(c -> c.defaultCodecs()
                		.maxInMemorySize(20 * 1024 * 1024)
                )
                .build();
    }

    @Bean
    WebClient webClient(ExchangeStrategies strategies) {
        return WebClient.builder()
                .baseUrl("http://localhost:8000")
                .exchangeStrategies(strategies)
                .build();
    }
}
