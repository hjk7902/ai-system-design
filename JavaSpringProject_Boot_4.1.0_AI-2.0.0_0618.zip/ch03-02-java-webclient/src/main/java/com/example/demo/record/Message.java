package com.example.demo.record;

public record Message(String role, String content) {}