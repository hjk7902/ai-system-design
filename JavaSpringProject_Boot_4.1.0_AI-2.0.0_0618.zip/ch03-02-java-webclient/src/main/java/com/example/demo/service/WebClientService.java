package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.demo.record.ChatRequest;
import com.example.demo.record.ChatResponse;
import com.example.demo.record.Message;

import reactor.core.publisher.Mono;

@Service
public class WebClientService {

	private static final String MODEL = "gpt-4o-mini";
	private final WebClient openAiWebClient;

	public WebClientService(@Qualifier("openAiWebClient") WebClient openAiWebClient) {
		this.openAiWebClient = openAiWebClient;
	}

	public Mono<String> getChatCompletion(String userInput) {

		ChatRequest request = new ChatRequest(
				MODEL,
				List.of(new Message("user", userInput))
				);

		return openAiWebClient.post()
				.uri("/chat/completions")
				.bodyValue(request)
				.retrieve()
				.bodyToMono(ChatResponse.class)
				.map(response -> {
					var choices = response.choices();
					if (choices == null || choices.isEmpty()) {
						return "응답 없음";
					}
					return choices.get(0).message().content();
				});
	}
}