package com.example.demo.record;

import java.util.List;

public record ChatResponse(List<Choice> choices) {}
