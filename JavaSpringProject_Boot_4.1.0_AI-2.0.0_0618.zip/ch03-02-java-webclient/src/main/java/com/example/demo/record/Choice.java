package com.example.demo.record;

public record Choice(Message message) {}