package com.example.demo.record;

import java.util.List;

public record ChatRequest(String model,	List<Message> messages) {}