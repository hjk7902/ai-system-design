package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.demo.record.ChatRequest;
import com.example.demo.record.ChatResponse;
import com.example.demo.record.Message;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(@Qualifier("openAiWebClient") WebClient client) {
        return _ -> {

            ChatRequest request = new ChatRequest(
                "gpt-4o-mini",
                List.of(new Message("user", "지구의 나이는?"))
            );

            ChatResponse response = client.post()
                .uri("/v1/chat/completions")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ChatResponse.class)
                .block();

            String content = response.choices().get(0).message().content();

            System.out.println("=== OpenAI Response ===");
            System.out.println(content);
        };
    }
}