package com.example.demo.model;

public record GeneratedImage(String b64Json) {}