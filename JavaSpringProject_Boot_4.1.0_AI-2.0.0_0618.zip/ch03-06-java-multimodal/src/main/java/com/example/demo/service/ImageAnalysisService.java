package com.example.demo.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.content.Media;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class ImageAnalysisService {

    private final ChatClient chatClient;

    public ImageAnalysisService(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }

    public Mono<String> analyze(FilePart image, String question) {
        return DataBufferUtils.join(image.content())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);

                    Media media = Media.builder()
                    		.mimeType(image.headers().getContentType())
                            .data(new ByteArrayResource(bytes))
                            .build();

                    return chatClient.prompt()
                            .user(u -> u.text(question).media(media))
                            .call()
                            .content();
                });
    }
}