package com.example.demo.controller;

import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.ImageAnalysisService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/vision")
public class ImageAnalysisController {

    private final ImageAnalysisService service;

    public ImageAnalysisController(ImageAnalysisService service) {
        this.service = service;
    }

    @PostMapping(
            value = "/analyze",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.TEXT_PLAIN_VALUE
    )
    public Mono<String> analyze(
            @RequestPart("image") FilePart image,
            @RequestPart("question") String question) {
        return service.analyze(image, question);
    }
}
