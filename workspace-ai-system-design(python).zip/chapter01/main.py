from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
 
app = FastAPI() 
 
class Item(BaseModel):
    name: str
    description: str = None
    price: float
    tax: float = 0.1

items = {100: Item(name='pen', price=12.5, tax=0.015),
         200: Item(name='book', price=25)}
 
@app.get("/")
async def index():
    return {"message": "Hello World"}

@app.get("/items/{item_id}")
async def read_item(item_id: int):
    if item_id not in items.keys():
        raise HTTPException(status_code=404, detail="Item 없음")
    return items[item_id]
 
@app.post("/items/")
async def create_item(item: Item):
    item_id = max(items.keys()) + 100
    items[item_id] = item
    return {"item_id": item_id, **item.model_dump()}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", port=8000, reload=True)