import base64
import io

import cv2
import numpy as np
from fastapi import FastAPI, UploadFile
from fastapi import File, Form, HTTPException
from fastapi.concurrency import run_in_threadpool
from PIL import Image
from pydantic import BaseModel
from ultralytics import YOLO

app = FastAPI()

model = YOLO("yolo26n.pt")


class DetectionResult(BaseModel):
    message: str
    image: str


@app.get("/")
async def index():
    return {"message": "Hello FastAPI"}


@app.post("/detect", response_model=DetectionResult)
async def detect(
    message: str = Form(...),
    file: UploadFile = File(...)
):
    try:
        image_bytes = await file.read()

        image = Image.open(
            io.BytesIO(image_bytes)
        ).convert("RGB")

        img = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

        result = await run_in_threadpool(
            lambda: model(img, conf=0.4, verbose=False)[0]
        )

        if result.boxes is not None:
            # for box, conf, cls in zip(
            #     result.boxes.xyxy,
            #     result.boxes.conf,
            #     result.boxes.cls
            # ):
            #     x1, y1, x2, y2 = map(int, box)

            #     label = model.names[int(cls)]

            #     cv2.rectangle(
            #         img,
            #         (x1, y1), (x2, y2),
            #         (255, 0, 0), 2
            #     )

            #     cv2.putText(
            #         img,
            #         f"{label} {conf:.2f}",
            #         (x1, y1 - 5),
            #         cv2.FONT_HERSHEY_SIMPLEX,
            #         0.7, (255, 0, 0), 2
            #     )
            img = result.plot()

        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        buffer = io.BytesIO()

        Image.fromarray(img).save(buffer, format="JPEG", quality=70)

        img_str = base64.b64encode(
            buffer.getvalue()
        ).decode()

        return DetectionResult(message=message, image=img_str)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000)