import requests
import base64

url = "http://localhost:8000/detect"
message = "Test message"
file_path = "sample.jpg"

with open(file_path, "rb") as file:
    response = requests.post(
        url,
        data={"message": message},
        files={"file": file}
    )

if response.status_code != 200:
    print("Request failed:", response.status_code)
    print(response.text)
    exit()

data = response.json()

print("message:", data["message"])

with open("output.jpg", "wb") as f:
    f.write(base64.b64decode(data["image"]))

print("saved: output.jpg")