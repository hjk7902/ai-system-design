import base64
import json
import cv2
import paho.mqtt.client as mqtt
from ultralytics import YOLO

model = YOLO('yolo26n.pt')


broker = 'localhost'
port = 1883
topic = '/camera/objects'

client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)

def on_connect(client, userdata, flags, reason_code, properties=None):
    print("Connected:", reason_code)

client.on_connect = on_connect # MQTT 서버에 연결되면 실행 되는 콜백 함수 설정

client.connect(broker, port) # MQTT 서버에 연결 

client.loop_start() # MQTT 네트워크 루프 시작 (비동기적으로 메시지 처리)

cap = cv2.VideoCapture(0)

try:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame, verbose=False)
        image = results[0].plot()

        _, buffer = cv2.imencode('.jpg', image, [1, 70])
        jpg_as_text = base64.b64encode(buffer).decode('utf-8')

        payload = json.dumps({'image': jpg_as_text})
        client.publish(topic, payload)

        cv2.imshow('Frame', image)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    cap.release()
    cv2.destroyAllWindows()
    client.loop_stop()
    client.disconnect()