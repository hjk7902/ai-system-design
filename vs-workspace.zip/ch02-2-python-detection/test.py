import requests
import base64

url = "http://localhost:8000/detect"
message = "Test message"
file_path = "sample.jpg"

with open(file_path, "rb") as file:
    response = requests.post(url, data={"message":message}, files={"file": file})

with open("output.png", "wb") as f:
    f.write(base64.b64decode(response.json()["image"]))
#print(response.json())