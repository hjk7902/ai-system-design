package com.example.myapp.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ChatConfig {

//    @Bean
//    ChatClient chatClient(OpenAiChatModel chatModel) {
//        return ChatClient.builder(chatModel).build();
//    }
    @Bean
    ChatClient chatClient(GoogleGenAiChatModel chatModel) {
        return ChatClient.builder(chatModel).build();
    }
}