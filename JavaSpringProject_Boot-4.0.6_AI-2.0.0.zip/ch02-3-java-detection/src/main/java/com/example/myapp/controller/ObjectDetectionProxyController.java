package com.example.myapp.controller;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@RestController
public class ObjectDetectionProxyController {

    private final WebClient webClient;

    public ObjectDetectionProxyController(
            @Qualifier("webClient") WebClient webClient
    ) {
        this.webClient = webClient;
    }

    @PostMapping("/api/detect/proxy")
    public Mono<String> service(
            @RequestPart("message") String message,
            @RequestPart("file") FilePart file
    ) {

        MultipartBodyBuilder builder = new MultipartBodyBuilder();

        builder.part("message", message);

        builder.asyncPart("file", file.content(), DataBuffer.class)
               .filename(file.filename())
               .contentType(
                   file.headers().getContentType() != null
                   ? file.headers().getContentType()
                   : MediaType.APPLICATION_OCTET_STREAM
               );

        return webClient.post()
                .uri("/detect")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(builder.build()))
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30));
    }
}