package com.example.myapp.model;

public record GeneratedImage(String b64Json) {}