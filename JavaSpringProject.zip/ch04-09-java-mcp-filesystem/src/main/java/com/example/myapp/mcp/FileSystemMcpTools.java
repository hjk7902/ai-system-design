package com.example.myapp.mcp;

import java.io.IOException;
import java.util.List;

import org.springaicommunity.mcp.annotation.McpTool;
import org.springaicommunity.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;

import com.example.myapp.service.FileSystemToolService;

@Component
public class FileSystemMcpTools {

    private final FileSystemToolService fs;

    public FileSystemMcpTools(FileSystemToolService fs) { 
        this.fs = fs; 
    }

    @McpTool(
        name = "file-search",
        description = "워크스페이스 하위에서 파일명을 기준으로 키워드를 포함하는 파일을 검색합니다. 상대 경로 목록을 반환합니다."
    )
    public List<String> search(
            @McpToolParam(
                description = "파일명과 매칭할 키워드 (대소문자 구분 없음)."
            )
            String keyword
    ) throws IOException {
        return fs.search(keyword);
    }

    @McpTool(
        name = "file-fetch",
        description = "상대 경로로 파일 내용을 조회합니다. 바이트 범위(offset/limit) 또는 라인 범위(startLine/endLine)를 지원합니다."
    )
    public String fetch(
            @McpToolParam(
                description = "설정된 워크스페이스 루트 기준의 상대 경로."
            ) String path,
            @McpToolParam(
                description = "바이트 오프셋 (0부터 시작). limit과 함께 사용."
            ) Long offset,
            @McpToolParam(
                description = "읽을 최대 바이트 수. offset과 함께 사용."
            ) Integer limit,
            @McpToolParam(
                description = "시작 라인 번호 (1부터 시작). endLine과 함께 사용."
            ) Integer startLine,
            @McpToolParam(
                description = "종료 라인 번호 (1부터 시작, 포함). startLine과 함께 사용."
            ) Integer endLine
    ) throws IOException {

        if (startLine != null && endLine != null) return fs.fetchLines(path, startLine, endLine);
        if (offset != null && limit != null) return fs.fetchRange(path, offset, limit);
        return fs.fetch(path);
    }
}
