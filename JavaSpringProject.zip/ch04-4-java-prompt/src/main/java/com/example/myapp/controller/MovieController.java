package com.example.myapp.controller;

import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.myapp.service.MovieService;

import reactor.core.publisher.Flux;

@RestController
public class MovieController {

    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping(value = "/movie/recommend")
    public String recommend(@RequestParam("q") String q) {
        return movieService.recommendMovies(q);
    }

    @GetMapping(value = "/movie/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> stream(@RequestParam("q") String q) {
        return movieService.streamRecommend(q)
        		.map(chunk -> ServerSentEvent.builder(chunk).build());
    }
}