package com.example.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch044JavaPromptApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch044JavaPromptApplication.class, args);
	}

}
