package com.example.myapp;

import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MyappApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyappApplication.class, args);
    }

    @Bean
    CommandLineRunner printMcpToolNames(
            @Qualifier("notionMcpToolCallbacks") ToolCallbackProvider provider
    ) {
        return args -> {
            var callbacks = provider.getToolCallbacks();
            System.out.println("===== MCP Tool List =====");
            System.out.println("count = " + callbacks.length);

            for (var cb : callbacks) {
            	var tool = cb.getToolDefinition();
            	String desc = tool.description();
            	String firstLine = (desc == null) ? "" : desc.split("\\R", 2)[0];
            	System.out.println("• " + tool.name() + " - " + firstLine);
            }
        };
    }
}
