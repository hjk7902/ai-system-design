package com.example.myapp;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class MyappApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyappApplication.class, args);
    }

    //@Bean 
    CommandLineRunner runner(@Qualifier("openAiWebClient") WebClient client, ObjectMapper mapper) {
        return args -> {
            Map<String, Object> requestBody = Map.of(
                "model", "gpt-4o-mini",
                "messages", List.of(
                    Map.of(
                        "role", "user",
                        "content", "지구의 나이는?"
                    )
                )
            );

            String response = client.post()
                    .uri("/chat/completions")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("=== OpenAI Response ===");
//            System.out.println(response);

            Map<?,?> result = mapper.readValue(response, Map.class);
            List<?> choices = (List<?>)result.get("choices");
            Map<?,?> firstChoice = (Map<?,?>) choices.get(0);
            Map<?,?> message = (Map<?,?>) firstChoice.get("message");
            String content = message.get("content").toString();
            System.out.println(content);
        };
    }
}