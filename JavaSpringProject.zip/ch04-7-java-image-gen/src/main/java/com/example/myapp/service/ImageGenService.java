package com.example.myapp.service;

import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.stereotype.Service;

import com.example.myapp.model.GeneratedImage;

@Service
public class ImageGenService {

    private final ImageModel imageModel;

    public ImageGenService(ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    public GeneratedImage generate(String promptText) {

        // 옵션을 코드에서 오버라이드하고 싶을 때 (yml 설정이 기본값)
        var options = OpenAiImageOptions.builder()
                .model("dall-e-3")
                .width(1792).height(1024) // 1024x1024, 1792x1024, 1024x1792 
                .quality("hd")  // standard, hd
                .style("vivid") // vivid, natural
                .responseFormat("b64_json") // "b64_json"도 가능
                .build();

        ImageResponse response = imageModel.call(new ImagePrompt(promptText, options));

        // 첫 번째 결과 꺼내기
        var result = response.getResult();
        var output = result.getOutput();

        // response_format에 따라 url 또는 b64Json이 채워집니다.
        return new GeneratedImage(
                output.getUrl(),       // response_format=url 일 때
                output.getB64Json(),   // response_format=b64_json 일 때
                result.getMetadata()   // 메타(있으면)
        );
    }

}

