package com.example.myapp.model;

public record GeneratedImage(
        String url,
        String b64Json,
        Object metadata
) {}