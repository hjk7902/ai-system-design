package com.example.myapp.controller;

import java.util.Set;

import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.myapp.model.GenerateImageRequest;
import com.example.myapp.model.GeneratedImage;

@RestController
@RequestMapping("/api/images")
public class ImageGenController {

    private final ImageModel imageModel;

    public ImageGenController(ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    // DALL·E 3 허용 해상도 (width x height)
    private static final Set<String> ALLOWED_SIZES = Set.of(
            "1024x1024",
            "1792x1024",
            "1024x1792"
    );

    @PostMapping(
            value = "/generate",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public GeneratedImage generate(@RequestBody GenerateImageRequest req) {

        if (req.prompt() == null || req.prompt().isBlank()) {
            throw new IllegalArgumentException("prompt is required");
        }

        int width  = (req.width()  == null) ? 1024 : req.width();
        int height = (req.height() == null) ? 1024 : req.height();

        String sizeKey = width + "x" + height;
        if (!ALLOWED_SIZES.contains(sizeKey)) {
            throw new IllegalArgumentException(
                    "Invalid size for dall-e-3. Allowed: " + ALLOWED_SIZES
            );
        }

        String quality = (req.quality() == null) ? "standard" : req.quality();
        String style = (req.style() == null) ? "vivid" : req.style();
        String responseFormat = (req.responseFormat() == null) ? "url" : req.responseFormat();

        OpenAiImageOptions options = OpenAiImageOptions.builder()
                .model("dall-e-3")
                .width(width)          // ✅ 1.1.2 방식
                .height(height)        // ✅ 1.1.2 방식
                .quality(quality)
                .style(style)
                .responseFormat(responseFormat)
                .build();

        ImageResponse response =
                imageModel.call(new ImagePrompt(req.prompt(), options));

        var result = response.getResult();
        var output = result.getOutput();

        return new GeneratedImage(
                output.getUrl(),
                output.getB64Json(),
                result.getMetadata()
        );
    }
}
