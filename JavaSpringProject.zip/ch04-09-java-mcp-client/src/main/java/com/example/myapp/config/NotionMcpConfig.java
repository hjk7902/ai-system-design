package com.example.myapp.config;

import java.net.http.HttpRequest;

import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.modelcontextprotocol.client.McpClient;
import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.client.transport.HttpClientStreamableHttpTransport;

@Configuration
public class NotionMcpConfig {

    @Bean(destroyMethod = "closeGracefully")
    McpSyncClient notionMcpClient(
            @Value("${notion.mcp.base-url}") String baseUrl,
            @Value("${notion.mcp.auth-token}") String authToken
    ) {
        HttpRequest.Builder rb = HttpRequest.newBuilder();
        rb.setHeader("Authorization", "Bearer " + authToken);
        rb.setHeader("Accept", "application/json, text/event-stream");

        var transport = HttpClientStreamableHttpTransport.builder(baseUrl)
                .endpoint("/mcp")
                .requestBuilder(rb)
                .build();

        var client = McpClient.sync(transport).build();
        client.initialize();
        return client;
    }

    @Bean(name = "notionMcpToolCallbacks")
    ToolCallbackProvider notionMcpToolCallbacks(McpSyncClient notionMcpClient) {
        return SyncMcpToolCallbackProvider.builder()
                .mcpClients(notionMcpClient)
                .build();
    }
}
