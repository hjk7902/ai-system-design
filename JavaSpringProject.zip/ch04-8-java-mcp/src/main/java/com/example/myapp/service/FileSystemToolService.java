package com.example.myapp.service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

@Service
public class FileSystemToolService {

    private final Props props;
    private final Path root;

    @ConfigurationProperties(prefix = "mcp.filesystem")
    public record Props(String rootDir, long maxFetchBytes, int maxSearchResults) {}

    public FileSystemToolService(Props props) {
        this.props = props;
        this.root = Paths.get(props.rootDir()).toAbsolutePath().normalize();
    }

    public List<String> search(String keyword) throws IOException {
        if (keyword == null || keyword.isBlank()) throw new IllegalArgumentException("keyword is required");

        String kw = keyword.toLowerCase();
        List<String> out = new ArrayList<>();

        try (var stream = Files.walk(root)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> p.getFileName()
                                  .toString()
                                  .toLowerCase().contains(kw))
                    .limit(props.maxSearchResults())
                    .forEach(p -> out.add(root.relativize(p)
                                              .toString()
                                              .replace('\\', '/')));
        }
        return out;
    }

    public String fetch(String relativePath) throws IOException {
        Path file = resolveUnderRoot(relativePath);
        long size = Files.size(file);

        if (size <= props.maxFetchBytes()) {
            return Files.readString(file, StandardCharsets.UTF_8);
        }

        String head = fetchRange(relativePath, 0L, props.maxFetchBytes());
        return head + "\n\n[[TRUNCATED]]";
    }

    public String fetchRange(String relativePath, long offset, long limit) throws IOException {
        if (offset < 0) 
            throw new IllegalArgumentException("offset must be >= 0");
        if (limit <= 0) 
            throw new IllegalArgumentException("limit must be > 0");

        long cappedLimit = Math.min(limit, props.maxFetchBytes());
        Path file = resolveUnderRoot(relativePath);

        long size = Files.size(file);
        if (offset >= size) return "";

        int toRead = (int) Math.min(cappedLimit, size - offset);

        try (var channel = FileChannel.open(file, StandardOpenOption.READ)) {
            channel.position(offset);
            ByteBuffer buf = ByteBuffer.allocate(toRead);
            int read = channel.read(buf);
            if (read <= 0) return "";
            buf.flip();
            return StandardCharsets.UTF_8.decode(buf).toString();
        }
    }

    public String fetchLines(String relativePath, int startLine, int endLine) throws IOException {
        if (startLine <= 0) 
            throw new IllegalArgumentException("startLine must be >= 1");
        if (endLine <= 0) 
            throw new IllegalArgumentException("endLine must be >= 1");
        if (endLine < startLine) 
            throw new IllegalArgumentException("endLine must be >= startLine");

        Path file = resolveUnderRoot(relativePath);

        StringBuilder sb = new StringBuilder();
        long maxCharsApprox = props.maxFetchBytes(); // UTF-8 근사치 제한(실무에선 바이트 정밀 계산도 가능)

        try (var lines = Files.lines(file, StandardCharsets.UTF_8)) {
            final int[] lineNo = {0};
            lines.forEachOrdered(line -> {
                lineNo[0]++;
                if (lineNo[0] < startLine) return;
                if (lineNo[0] > endLine) return;

                String withNl = line + "\n";
                if (sb.length() + withNl.length() > maxCharsApprox) return;
                sb.append(withNl);
            });
        }

        return sb.toString();
    }

    private Path resolveUnderRoot(String relativePath) throws IOException {
        if (relativePath == null || relativePath.isBlank()) 
            throw new IllegalArgumentException("path is required");

        Path candidate = root.resolve(relativePath).normalize();
        if (!candidate.startsWith(root)) 
            throw new SecurityException("Access denied: path traversal");
        if (!Files.exists(candidate) || !Files.isRegularFile(candidate)) 
            throw new NoSuchFileException("Not found: " + relativePath);

        return candidate;
    }
}