package com.example.myapp.mcp;

import java.io.IOException;
import java.util.List;

import org.springaicommunity.mcp.annotation.McpTool;
import org.springaicommunity.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;

import com.example.myapp.service.FileSystemToolService;

@Component
public class FileSystemMcpTools {

    private final FileSystemToolService fs;

    public FileSystemMcpTools(FileSystemToolService fs) { 
        this.fs = fs; 
    }

    @McpTool(name = "file-search",
             description = "Find files under the workspace whose filename contains the keyword. Returns relative paths.")
    public List<String> search(
            @McpToolParam(description = "Keyword to match against filenames (case-insensitive).")
            String keyword
    ) throws IOException {
        return fs.search(keyword);
    }

    @McpTool(name = "file-fetch",
             description = "Fetch file content by relative path. Supports byte range (offset/limit) or line range (startLine/endLine).")
    public String fetch(
            @McpToolParam(description = "Relative path under the configured workspace root.") String path,
            @McpToolParam(description = "Byte offset (0-based). Use with limit.") Long offset,
            @McpToolParam(description = "Max bytes to read. Use with offset.") Integer limit,
            @McpToolParam(description = "Start line (1-based). Use with endLine.") Integer startLine,
            @McpToolParam(description = "End line (1-based, inclusive). Use with startLine.") Integer endLine
    ) throws IOException {

        if (startLine != null && endLine != null) return fs.fetchLines(path, startLine, endLine);
        if (offset != null && limit != null) return fs.fetchRange(path, offset, limit);
        return fs.fetch(path);
    }
}
