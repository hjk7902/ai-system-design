package com.example.myapp.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.rag.advisor.RetrievalAugmentationAdvisor;
import org.springframework.ai.rag.retrieval.search.VectorStoreDocumentRetriever;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class ChatService {
	
    private final ChatClient chatClient;
    private final VectorStore vectorStore;
    
    private final VectorStoreDocumentRetriever retriever;
    private final RetrievalAugmentationAdvisor ragAdvisor;

    // 폴백 기준 (운영에서 조정)
    private static final double SIM_THRESHOLD = 0.50;
    private static final int TOP_K = 1;

    public ChatService(ChatClient chatClient, VectorStore vectorStore) {
        this.chatClient = chatClient;
        this.vectorStore = vectorStore;

        this.retriever = VectorStoreDocumentRetriever.builder()
            .vectorStore(vectorStore)
            .similarityThreshold(SIM_THRESHOLD)
            .topK(TOP_K)
            .build();

        this.ragAdvisor = RetrievalAugmentationAdvisor.builder()
            .documentRetriever(this.retriever)
            .build();
    }

    public Flux<String> chatMemoryStream(String userInput, String userId) {

        boolean useRag  = hasRelevantDocs(userInput);
        
        var prompt = chatClient.prompt()
                .user(userInput)
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, userId));
        
        if (useRag ) {
        	prompt.advisors(ragAdvisor); // RAG 결과가 있을 경우
        }

        return prompt.stream()
                .content()
                .map(this::preserveSseLeadingSpace)
                .concatWith(Flux.just("[[END]]"));
    }

    private boolean hasRelevantDocs(String userInput) {
        var results = vectorStore.similaritySearch(
            SearchRequest.builder()
                .query(userInput)
                .topK(TOP_K)
                .filterExpression("type == 'quote'")
                .similarityThreshold(SIM_THRESHOLD)
                .build()
        );
        System.out.println(results);
        return results != null && !results.isEmpty();
    }
    
    private String preserveSseLeadingSpace(String chunk) {
        if (chunk == null) return "";
        return chunk.startsWith(" ") ? " " + chunk : chunk;
    }
}
