package com.example.myapp.rag;

import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class VectorStoreBootstrap {

    private static final String INIT_MARKER_TEXT = "__BOOTSTRAP_V1__";

    private final VectorStore vectorStore;

    public VectorStoreBootstrap(VectorStore vectorStore) {
        this.vectorStore = vectorStore;
    }

    @PostConstruct
    public void bootstrap() {
        if (isAlreadyBootstrapped(vectorStore)) {
            return;
        }

        List<Document> documents = List.of(
            // ✅ 초기화 마커 문서 (이걸로 “우리 앱이 이미 넣었는지” 판단)
            new Document(
                INIT_MARKER_TEXT,
                Map.of("type", "bootstrap", "version", "v1", "app", "myapp")
            ),

            // ✅ 실제 RAG 문서들
            new Document(
                "Spring AI rocks!! Spring AI rocks!! Spring AI rocks!!",
                Map.of("docId", "seed-1", "topic", "spring-ai")
            ),
            new Document(
                "세상은 크고 구원은 세상의 모퉁이에 있습니다.",
                Map.of("docId", "seed-2", "type", "quote", "author", "unknown")
            ),
            new Document(
                "과거를 향해 앞으로 걸어가고 미래를 향해 되돌아갑니다.",
                Map.of("docId", "seed-3", "type", "quote", "theme", "time")
            )
        );

        vectorStore.add(documents);
    }

    boolean isAlreadyBootstrapped(VectorStore vectorStore) {
        var results = vectorStore.similaritySearch(
            SearchRequest.builder()
                .query(INIT_MARKER_TEXT)
                .topK(1)
                .filterExpression("type == 'bootstrap' && app == 'myapp'")
                .build()
        );
        return results != null && !results.isEmpty();
    }

}
