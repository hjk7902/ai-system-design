package com.example.demo.controller;

import java.util.List;

import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.ChatService;

import reactor.core.publisher.Flux;

@RestController
public class ChatController {

    private final ChatService chatService;
    private final ChatMemory chatMemory;

    public ChatController(ChatService chatService, ChatMemory chatMemory) {
        this.chatService = chatService;
        this.chatMemory = chatMemory;
    }

    @GetMapping("/chat")
    public String chat(
            @RequestParam("id") String id,
            @RequestParam("q") String q) {

        return chatService.chatMemory(q, id);
    }

    @GetMapping(value = "/chat/stream", produces = "text/event-stream")
    public Flux<ServerSentEvent<String>> memoryStream(
            @RequestParam("id") String id,
            @RequestParam("q") String q) {

        return toSse(chatService.chatMemoryStream(q, id));
    }

    @PostMapping(value = "/chat/stream/image", produces = "text/event-stream")
    public Flux<ServerSentEvent<String>> imageStream(
            @RequestPart("id") String id,
            @RequestPart("q") String q,
            @RequestPart("image") FilePart image) {

        return toSse(chatService.chatImageStream(q, id, image));
    }

    @GetMapping("/chat/history")
    public List<ChatMsgDto> history(
            @RequestParam("conversationId") String conversationId) {

        return chatMemory.get(conversationId)
                .stream()
                .map(m -> new ChatMsgDto(
                        m.getMessageType().name(),
                        m.getText()))
                .toList();
    }

    private Flux<ServerSentEvent<String>> toSse(Flux<String> stream) {
        return stream.map(chunk ->
                ServerSentEvent.<String>builder()
                        .data(chunk)
                        .build());
    }

    public record ChatMsgDto(String role, String content) {
    }
}

