package com.example.demo.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class ChatService {

    private static final MediaType IMAGE_WEBP = MediaType.valueOf("image/webp");
    private static final String END_MARKER = "[[END]]";

    private final ChatClient chatClient;

    public ChatService(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public String chatMemory(String userInput, String userId) {
        return chatClient.prompt()
                .user(userInput)
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, userId))
                .call()
                .content();
    }

    public Flux<String> chatMemoryStream(String userInput, String userId) {
        return chatClient.prompt()
                .user(userInput)
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, userId))
                .stream()
                .content()
                .map(this::preserveSseLeadingSpace)
                .concatWithValues(END_MARKER);
    }

    public Flux<String> chatImageStream(
            String userInput,
            String userId,
            FilePart image) {

        if (image == null) {
            return Flux.error(
                    new IllegalArgumentException("이미지가 첨부되지 않았습니다."));
        }

        MediaType mediaType = getMediaType(image);

        if (!isSupportedImage(mediaType)) {
            return Flux.error(
                    new IllegalArgumentException(
                            "지원하지 않는 이미지 형식입니다: " + mediaType));
        }

        Path tempFile;
        try {
            tempFile = Files.createTempFile(
                    "gemma-image-",
                    getExtension(mediaType));
        } catch (IOException e) {
            return Flux.error(e);
        }

        return image.transferTo(tempFile)
                .thenMany(Flux.defer(() ->
                        createImageStream(
                                userInput,
                                userId,
                                mediaType,
                                tempFile)))
                .doFinally(_ -> deleteTempFile(tempFile));
    }

    private Flux<String> createImageStream(
            String userInput,
            String userId,
            MediaType mediaType,
            Path tempFile) {

        FileSystemResource resource =
                new FileSystemResource(tempFile.toFile());

        return chatClient.prompt()
                .user(user -> user
                        .text(userInput)
                        .media(mediaType, resource))
                .advisors(a -> a.param(
                        ChatMemory.CONVERSATION_ID,
                        userId))
                .stream()
                .content()
                .doOnNext(chunk ->
                        System.out.println(
                                "[IMAGE AI CHUNK] >>> "
                                        + visibleWhitespace(chunk)
                                        + " <<<"))
                .map(this::preserveSseLeadingSpace)
                .concatWithValues(END_MARKER);
    }

    private MediaType getMediaType(FilePart image) {
        MediaType mediaType = image.headers().getContentType();
        return mediaType != null
                ? mediaType
                : MediaType.IMAGE_JPEG;
    }

    private void deleteTempFile(Path tempFile) {
        try {
            Files.deleteIfExists(tempFile);
        } catch (IOException e) {
            System.err.println(
                    "임시 이미지 파일 삭제 실패: " + e.getMessage());
        }
    }

    private String preserveSseLeadingSpace(String chunk) {
        if (chunk == null || chunk.isEmpty()) {
            return "";
        }
        return chunk.startsWith(" ")
                ? " " + chunk
                : chunk;
    }

    private String visibleWhitespace(String text) {
        if (text == null) {
            return "";
        }
        return text
                .replace(" ", "_")
                .replace("\n", "↵\n")
                .replace("\r", "␍")
                .replace("\t", "→");
    }

    private boolean isSupportedImage(MediaType mediaType) {
        return MediaType.IMAGE_JPEG.isCompatibleWith(mediaType)
                || MediaType.IMAGE_PNG.isCompatibleWith(mediaType)
                || MediaType.IMAGE_GIF.isCompatibleWith(mediaType)
                || IMAGE_WEBP.isCompatibleWith(mediaType);
    }

    private String getExtension(MediaType mediaType) {
        if (MediaType.IMAGE_PNG.isCompatibleWith(mediaType)) {
            return ".png";
        }
        if (MediaType.IMAGE_GIF.isCompatibleWith(mediaType)) {
            return ".gif";
        }
        if (IMAGE_WEBP.isCompatibleWith(mediaType)) {
            return ".webp";
        }
        return ".jpg";
    }
}

